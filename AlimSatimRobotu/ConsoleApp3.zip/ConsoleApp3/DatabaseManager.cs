﻿using ConsoleApp3.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class DatabaseManager
    {
        private static SqlConnection OpenConnection()
        {
            var conn = new SqlConnection(@"Data Source=.;Initial Catalog=test;User ID=sa;Password=1;Connection Timeout=30;Min Pool Size=5;Max Pool Size=15;Pooling=true;TrustServerCertificate=True;");
            conn.Open();
            return conn;    
        }

        public static void Execute()
        {
            string query = $"";
            var cmd = new SqlCommand(query);
            cmd.Connection= OpenConnection();
            cmd.CommandText = query;
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
          
        }

        public static Hisse HisseGetir(string hisseAdi) {


            SqlCommand cmd = OpenConnection().CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = OpenConnection();
            cmd.CommandText = $"select * from Hisse where HisseAdi='${hisseAdi}'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            Hisse hisse = new Hisse();
            if (dt.Rows.Count > 0)
            {   
                hisse.Id = Convert.ToInt64(dt.Columns["Id"]);
                hisse.HisseAdi = Convert.ToString(dt.Columns["HisseAdi"]);
                hisse.IlkFiyat = Convert.ToDouble(dt.Columns["IlkFiyat"]);
                hisse.Butce = Convert.ToDouble(dt.Columns["Butce"]);
                hisse.BaslangicKademe = Convert.ToDouble(dt.Columns["BaslangicKademe"]);
                hisse.AlimTutari = Convert.ToDouble(dt.Columns["AlimTutari"]);
                hisse.SonAlimTutari = Convert.ToDouble(dt.Columns["SonAlimTutari"]);
                hisse.PortfoyTarihi = Convert.ToDateTime(dt.Columns["PortfoyTarihi"]);
                hisse.SonIslemTarihi = Convert.ToDateTime(dt.Columns["SonIslemTarihi"]);
                hisse.Aktif = Convert.ToBoolean(dt.Columns["Aktif"]);


            }
            cmd.Connection.Close();

            return hisse;

        }

        public static HisseHareket HisseHareketGetir(string hisseAdi, double fiyat, double marj)
        {


            SqlCommand cmd = OpenConnection().CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = OpenConnection();
            cmd.CommandText = $"sel_HisseHareket";
            cmd.Parameters.AddWithValue("@HisseAdi", hisseAdi);
            cmd.Parameters.AddWithValue("@Fiyat", fiyat);
            cmd.Parameters.AddWithValue("@Marj", marj);

            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            HisseHareket hisse = new HisseHareket();
            if (dt.Rows.Count > 0)
            {
                hisse.Id = Convert.ToInt64(dt.Columns["Id"]);
                hisse.Fiyat = Convert.ToDouble(dt.Columns["Fiyat"]);
                hisse.Lot = Convert.ToInt32(dt.Columns["Lot"]);
            }
            cmd.Connection.Close();

            return hisse;

        }

        public static HisseHareket HisseAlimKontrol(string hisseAdi, double fiyat, double marj)
        {


            SqlCommand cmd = OpenConnection().CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = OpenConnection();
            cmd.CommandText = $"[dbo].[sel_hisseAlimKontrol]";
            cmd.Parameters.AddWithValue("@HisseAdi", hisseAdi);
            cmd.Parameters.AddWithValue("@Fiyat", fiyat);
            cmd.Parameters.AddWithValue("@Fiyat", marj);

            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            HisseHareket hisse = new HisseHareket();
            if (dt.Rows.Count > 0)
            {
                hisse.Id = Convert.ToInt64(dt.Columns["Id"]);
                hisse.Fiyat = Convert.ToDouble(dt.Columns["Fiyat"]);
                hisse.Lot = Convert.ToInt32(dt.Columns["Lot"]);
            }
            cmd.Connection.Close();

            return hisse;

        }

        public static HisseHareket HisseSatimKontrol(string hisseAdi, double fiyat)
        {


            SqlCommand cmd = OpenConnection().CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = OpenConnection();
            cmd.CommandText = $"[dbo].[sel_hisseSatimKontrol]";
            cmd.Parameters.AddWithValue("@HisseAdi", hisseAdi);
            cmd.Parameters.AddWithValue("@Fiyat", fiyat);


            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            HisseHareket hisse = new HisseHareket();
            if (dt.Rows.Count > 0)
            {
                hisse.Id = Convert.ToInt64(dt.Columns["Id"]);
                hisse.Fiyat = Convert.ToDouble(dt.Columns["Fiyat"]);
                hisse.Lot = Convert.ToInt32(dt.Columns["Lot"]);
            }
            cmd.Connection.Close();

            return hisse;

        }

        public static void HisseEkleGuncelle(Hisse hisse)
        {


            SqlCommand cmd = OpenConnection().CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = OpenConnection();
            cmd.CommandText = "ins_Hisse";
     
            cmd.Parameters.AddWithValue("@HisseAdi", hisse.HisseAdi);
            cmd.Parameters.AddWithValue("@IlkFiyat", hisse.IlkFiyat);
            cmd.Parameters.AddWithValue("@Butce", hisse.Butce);
            cmd.Parameters.AddWithValue("@BaslangicKademe", hisse.BaslangicKademe);
            cmd.Parameters.AddWithValue("@AlimTutari", hisse.AlimTutari);
            cmd.Parameters.AddWithValue("@SonAlimTutari", hisse.SonAlimTutari);
            cmd.Parameters.AddWithValue("@PortfoyTarihi", hisse.PortfoyTarihi);
            cmd.Parameters.AddWithValue("@SonIslemTarihi", hisse.SonIslemTarihi);
            cmd.Parameters.AddWithValue("@Aktif", hisse.Aktif);

            cmd.ExecuteNonQuery();
            cmd.Connection.Close();

        }

        public static void HisseHareketEkleGuncelle(HisseHareket hisseHareket)
        {


            SqlCommand cmd = OpenConnection().CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = OpenConnection();
            cmd.CommandText = "ins_HisseHareket";

            cmd.Parameters.AddWithValue("@Id", hisseHareket.Id);
            cmd.Parameters.AddWithValue("@HisseAdi", hisseHareket.HisseAdi);
            cmd.Parameters.AddWithValue("@Lot", hisseHareket.Lot);
            cmd.Parameters.AddWithValue("@AlisFiyati", hisseHareket.AlisFiyati);
            cmd.Parameters.AddWithValue("@SatisFiyati", hisseHareket.SatisFiyati);
            cmd.Parameters.AddWithValue("@Lot", hisseHareket.Lot);

  
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();

        }


    }
}
