﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Samples
    {
        void Sample1(dynamic Sistem)
        {
            var Sembol = "VIP'VIP-X030";
            var Periyot = "5";

            var V = Sistem.GrafikVerileriniOku(Sembol, Periyot);
            var C = Sistem.GrafikFiyatOku(V, "Kapanis");
            var MA = Sistem.MA(C, "Exp", 20);

            var SartAl = false;
            var SartSat = false;
            var SonYon = "";
            var LotSize = 2.0;


            for (int i = 1; i < V.Count - 1; i++)
            {
                if (((C[i] > MA[i])) && SonYon != "A") // alış
                {
                    SonYon = "A";
                    if (i == V.Count - 2) SartAl = true;
                }
                if (((C[i] < MA[i])) && SonYon != "S") // satış
                {
                    SonYon = "S";
                    if (i == V.Count - 2) SartSat = true;
                }
            }


            // emir gönder
            var Islem = "";
            var Miktar = 0.0;
            var SonFiyat = Sistem.SonFiyat(Sembol);
            var Pozisyon = Sistem.PozisyonKontrolOku(Sistem.Name + " , " + Sembol);

            if (SartAl && Pozisyon <= 0) // alış
            {
                Islem = "ALIS";
                if (Pozisyon == 0) // pozisyonum yoksa 1 lot al
                    Miktar = LotSize;
                else if (Pozisyon < 0) // short isem stop and reverse , 2 lot al
                    Miktar = LotSize + Math.Abs(Pozisyon);
            }
            else if (SartSat && Pozisyon >= 0) // satış
            {
                Islem = "SATIS";
                if (Pozisyon == 0) // pozisyonum yoksa 1 lot sat
                    Miktar = LotSize;
                else if (Pozisyon > 0) // long isem stop and reverse , 2 lot sat
                    Miktar = LotSize + Math.Abs(Pozisyon);
            }

            // Emir Gönder !!!
            if (Islem != "")
            {
                if (Islem == "ALIS")
                    Sistem.PozisyonKontrolGuncelle(Sistem.Name + " , " + Sembol, LotSize);
                else if (Islem == "SATIS")
                    Sistem.PozisyonKontrolGuncelle(Sistem.Name + " , " + Sembol, -LotSize);
                Sistem.EmirSembol = Sembol;
                Sistem.EmirIslem = Islem;
                Sistem.EmirMiktari = Miktar;
                Sistem.EmirSuresi = "GUN"; // GUN, SNS, IKG
                Sistem.EmirTipi = "KPY"; // KPY, KIE, GIE, SAR
                Sistem.EmirFiyatTipi = "PYS"; // PYS, LMT, EIF, KAP
                Sistem.EmirGonder();
            }
        }


    }
}
