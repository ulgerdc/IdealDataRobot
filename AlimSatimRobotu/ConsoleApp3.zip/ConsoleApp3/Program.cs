﻿using ConsoleApp3;
using ConsoleApp3.Entity;

//GridTradingBot.Start();

var hisseAdi = "HEKTS";
var marj = 0.003D;
var lot = 10;

var hisse = DatabaseManager.HisseGetir(hisseAdi);
if (hisse is null)
    return;

var sonfiyat = IdealManager.SonFiyatGetir();
var marjliFiyat = sonfiyat - (sonfiyat * marj);

var hisseSatimKontrol = DatabaseManager.HisseSatimKontrol(hisseAdi, marjliFiyat);
if (hisseSatimKontrol != null)
{
    IdealManager.Sat(hisse, lot, marjliFiyat);
    var hisseSat = new HisseHareket();
    hisseSat.Id = hisseSatimKontrol.Id;
    hisseSat.SatisFiyati = sonfiyat;
    hisseSat.HisseAdi = hisseSatimKontrol.HisseAdi;
    hisseSat.Lot = hisseSatimKontrol.Lot;
    DatabaseManager.HisseHareketEkleGuncelle(hisseSat);
}
else
{
    //marjliFiyat = sonfiyat - (sonfiyat * marj);
    var hisseAlimKontrol = DatabaseManager.HisseAlimKontrol(hisseAdi, sonfiyat, marj);
    if (hisseAlimKontrol == null)
    {
        IdealManager.Al(hisse, lot, sonfiyat);
        var hisseAl = new HisseHareket();
        hisseAl.AlisFiyati = marjliFiyat;
        hisseAl.HisseAdi = hisseAdi;
        hisseAl.Lot = lot;
        DatabaseManager.HisseHareketEkleGuncelle(hisseAl);
    }
}


Console.WriteLine("Hello, World!");

static void HisseIlkAlim(string hisseAdi)
{
        var hisse = new Hisse();
        hisse.HisseAdi = hisseAdi;
        hisse.Aktif = true;
        hisse.Butce = 30000;
        hisse.AlimTutari = 1000;
        hisse.PortfoyTarihi = DateTime.Now.Date;
        hisse.IlkFiyat = 24.05D;
        hisse.SonAlimTutari = 24.05D;
        hisse.SonIslemTarihi = DateTime.Now.Date;
        DatabaseManager.HisseEkleGuncelle(hisse);

}





