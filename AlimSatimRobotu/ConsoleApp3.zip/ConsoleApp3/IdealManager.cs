﻿using ConsoleApp3.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class IdealManager
    {
        public static void Al(Hisse hisse, int lot, double fiyat)
        {

            hisse.SonAlimTutari = fiyat;
            hisse.SonIslemTarihi = DateTime.Now.Date;
            DatabaseManager.HisseEkleGuncelle(hisse);

            HisseHareket hisseHareket = new HisseHareket();
            hisseHareket.AlimSatim = AlimSatimEnum.Alim;
            hisseHareket.IslemTarihi = DateTime.Now;
            hisseHareket.Lot = lot;
            hisseHareket.Fiyat = fiyat;
            DatabaseManager.HisseHareketEkleGuncelle(hisseHareket);


        }

        public static void Sat(Hisse hisse, int lot, double fiyat)
        {

        }

        internal static double SonFiyatGetir()
        {
            return new Random().Next(90, 110);
        }
    }
}
