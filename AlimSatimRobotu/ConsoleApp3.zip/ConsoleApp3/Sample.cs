﻿using System;
using System.Threading;

namespace ConsoleApp3;
public class GridTradingBot 
{ 
    public static void Start() 
    { 
      
        double initialPrice = 100.0;
        double gridSpacing = 1.0; 
        int numberOfGrids = 10; 
        double buyAmount = 10.0; 
        double sellAmount = 10.0; 
        // Trading loop
        while (true) 
        { 
            double currentPrice = GetMarketPrice("YourTradingPair"); 
            for (int i = 0; i < numberOfGrids; i++) 
            { 
                double buyPrice = initialPrice + i * gridSpacing; 
                double sellPrice = initialPrice - i * gridSpacing; 
     
                if (currentPrice >= buyPrice) 
                { 
                    PlaceBuyOrder("YourTradingPair", buyAmount, buyPrice); 
                } 
                if (currentPrice <= sellPrice) 
                { 
                    PlaceSellOrder("YourTradingPair", sellAmount, sellPrice); 
                } 
            } 
           
            Thread.Sleep(10000);
         } 
    }

    private static double GetMarketPrice(string v)
    {
        return new Random().Next(90, 110);
    }

    private static void PlaceSellOrder(string v, double sellAmount, double sellPrice)
    {
        Console.WriteLine($"Sell {v} {sellAmount} {sellPrice}");
    }

    private static void PlaceBuyOrder(string v, double buyAmount, double buyPrice)
    {
        Console.WriteLine($"Buy {v} {buyAmount} {buyPrice}");
    }
}