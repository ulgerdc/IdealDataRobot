﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3.Entity
{
    internal class Hisse
    {
        public long Id { get; set; }
        public string HisseAdi { get; set; }
        public double IlkFiyat { get; set; }
        public double Butce { get; set; }
        public double BaslangicKademe { get; set; }
        public double AlimTutari { get; set; }
        public double SonAlimTutari { get; set; }
        public DateTime PortfoyTarihi { get; set; }
        public DateTime SonIslemTarihi { get; set; }
        public bool Aktif { get; set; }
    }
}
