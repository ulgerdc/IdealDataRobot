﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3.Entity
{
    internal class HisseHareket
    {
        public long Id { get; set; }
        public string HisseAdi { get; internal set; }
        public double AlisFiyati { get; internal set; }
        public double SatisFiyati { get; internal set; }
        public int Lot { get; set; }
    }
}
