﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3.Entity
{
    internal class HisseDefter
    {
        public long HisseAdi { get; set; }
        public double GunlukAlim { get; set; }
        public double GunlukSatim { get; set; }
        public DateTime IslemTarihi { get; set; }

    }
}
